package bank.entities.loan;

public class StudentLoan extends BaseLoan{
    public StudentLoan() {
        super(1, 10_000);
    }




}
