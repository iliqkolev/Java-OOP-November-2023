package handball.entities.gameplay;

public class Outdoor extends BaseGameplay{
    public Outdoor(String name) {
        super(name,150);
    }

}
