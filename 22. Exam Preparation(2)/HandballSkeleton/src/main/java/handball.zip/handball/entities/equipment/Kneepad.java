package handball.entities.equipment;

public class Kneepad extends BaseEquipment{
    public Kneepad() {
        super(120, 15.00);
    }
}
