package harpoonDiver.models.diver;

public class WreckDiver extends BaseDiver{
    public WreckDiver(String name) {
        super(name, 150.0);
    }
}
