package Vehicles;

public interface Vehicle {
    String drive(double distance);
    void refuel(double liters);

}
