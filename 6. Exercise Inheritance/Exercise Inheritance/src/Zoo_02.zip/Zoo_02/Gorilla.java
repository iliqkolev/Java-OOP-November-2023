package Zoo_02;

public class Gorilla extends Mammal {
    public Gorilla(String name) {
        super(name);
    }
}
