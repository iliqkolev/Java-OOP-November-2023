package PlayersAndMonsters_03;

public class MuseElf extends Elf{
    public MuseElf(String username, int level) {
        super(username, level);
    }
}
