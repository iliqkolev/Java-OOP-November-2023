package NeedForSpeed_04;

public class Motorcycle extends Vehicle{
    public Motorcycle(double fuel, int horsePower) {
        super(fuel, horsePower);
    }
}
