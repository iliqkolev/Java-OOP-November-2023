package christmasPastryShop.entities.booths.interfaces;

public class PrivateBooth extends BaseBooth{
    public PrivateBooth(int boothNumber, int capacity, double pricePerPerson) {
        super(boothNumber, capacity, pricePerPerson - 3.50);
    }
}
