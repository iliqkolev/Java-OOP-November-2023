package christmasPastryShop.entities.delicacies.interfaces;

public class Gingerbread extends BaseDelicacy{
    public Gingerbread(String name, double price) {
        super(name, 200, price);
    }

}
