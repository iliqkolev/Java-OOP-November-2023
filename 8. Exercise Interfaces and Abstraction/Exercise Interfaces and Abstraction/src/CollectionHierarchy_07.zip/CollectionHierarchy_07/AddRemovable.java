package CollectionHierarchy_07;

public interface AddRemovable extends Addable{
    String remove();
}
