package MultipleImplementation_02;

public interface Birthable {
    String getBirthDate();
}
