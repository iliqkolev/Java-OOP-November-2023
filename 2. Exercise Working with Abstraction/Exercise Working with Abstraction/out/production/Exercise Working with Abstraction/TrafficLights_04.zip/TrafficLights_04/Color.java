package TrafficLights_04;

public enum Color {
    RED,
    GREEN,
    YELLOW
}
