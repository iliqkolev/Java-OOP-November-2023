package CardSuit;

public enum CardSuits {
    CLUBS, // спатия
    DIAMONDS, // каро
    HEARTS, // купа
    SPADES // пика
}
