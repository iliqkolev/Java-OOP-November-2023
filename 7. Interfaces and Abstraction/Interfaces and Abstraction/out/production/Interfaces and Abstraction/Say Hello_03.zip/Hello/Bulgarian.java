package Hello;

public class Bulgarian extends PersonImpl{
    protected Bulgarian(String name) {
        super(name);
    }

    @Override
    public String sayHello() {
        return "Здравей";
    }
}
