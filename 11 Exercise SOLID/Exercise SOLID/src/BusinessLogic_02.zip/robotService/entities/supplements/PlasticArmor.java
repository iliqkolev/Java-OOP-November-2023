package robotService.entities.supplements;

public class PlasticArmor extends BaseSupplement{
    public static final int HARDNESS=1;
    public static final double PRICE=10;
    public PlasticArmor() {
        super(HARDNESS, PRICE);
    }

}
