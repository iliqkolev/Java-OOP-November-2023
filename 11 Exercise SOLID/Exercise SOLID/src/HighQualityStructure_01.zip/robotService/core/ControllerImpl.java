package robotService.core;

public class ControllerImpl implements Controller{
    @Override
    public String addService(String type, String name) {
        return null;
    }

    @Override
    public String addSupplement(String type) {
        return null;
    }

    @Override
    public String supplementForService(String serviceName, String supplementType) {
        return null;
    }

    @Override
    public String addRobot(String serviceName, String robotType, String robotName, String robotKind, double price) {
        return null;
    }

    @Override
    public String feedingRobot(String serviceName) {
        return null;
    }

    @Override
    public String sumOfAll(String serviceName) {
        return null;
    }

    @Override
    public String getStatistics() {
        return null;
    }
}
