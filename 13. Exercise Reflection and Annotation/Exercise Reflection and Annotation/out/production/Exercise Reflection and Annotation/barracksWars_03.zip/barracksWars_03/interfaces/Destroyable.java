package barracksWars_03.interfaces;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
