package barracksWars_03.interfaces;

public interface Runnable {
	void run();
}
